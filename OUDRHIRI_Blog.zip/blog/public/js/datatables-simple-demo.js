window.addEventListener('DOMContentLoaded', event => {
    // Simple-DataTables
    // https://github.com/fiduswriter/Simple-DataTables/wiki

    const datatablesSimple = document.getElementById('datatablesSimple');
    if (datatablesSimple) {
        new simpleDatatables.DataTable(datatablesSimple,{
            searchable: false,
            // "lengthChange":false
        });
        
    }
});



// $(document).ready( function () {
//     // $('#table_id').DataTable();
//     document.getElementById('datatablesSimple').dataTable( {
//         "pageLength": 6,
//         lengthChange:false,
//         "searching": false,
//         "language": {
//         "url": "datatables/ar.json"
//         }
//     } );
    
// } );