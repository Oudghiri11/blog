<?php

namespace App\Form;

use App\Entity\Article;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use App\Entity\Categorie;
use App\Entity\MotCle;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;

class ArticleType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('titre')
            ->add('contenu')
            ->add('categorie', EntityType::class, [
                'class'        => Categorie::class,
                'choice_label' => 'categorie',
                'label'        => 'Categories de l\'article?',
                'expanded'     => true,
                'multiple'     => true,
            ])
            ->add('mots_cles', EntityType::class, [
                'class'        => MotCle::class,
                'choice_label' => 'mot_cle',
                'label'        => 'Mots clés de l\'article?',
                'expanded'     => true,
                'multiple'     => true,
            ])
            // ->add('date_creation')
            // ->add('date_modification')
        ;
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Article::class,
        ]);
    }
}
