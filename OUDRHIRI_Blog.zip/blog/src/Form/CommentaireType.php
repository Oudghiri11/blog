<?php

namespace App\Form;

use App\Entity\Commentaire;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Security\Core\Security;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use App\Entity\Utilisateur;

class CommentaireType extends AbstractType
{
    private $security;

    public function __construct(Security $security)
    {
        $this->security = $security;
    }
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        // dump($this->security->getUser());exit;
        $builder
            ->add('contenu')
            // ->add('utilisateur',
            //     EntityType::class, [
            //         // 'label' => 'utilisateur',
            //         'class' => Utilisateur::class,
            //         'data' => $this->security->getUser(),
            //         // 'empty_data' => 'Default value'
            //     ])
            // ->add('date_creation')
        ;
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Commentaire::class,
        ]);
    }
}
